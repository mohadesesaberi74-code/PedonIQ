
const $=id=>document.getElementById(id);let fields=JSON.parse(localStorage.getItem('piq_fields')||'[]'),samples=JSON.parse(localStorage.getItem('piq_samples')||'[]'),micro=JSON.parse(localStorage.getItem('piq_micro')||'[]'),lang='fa';
function save(){localStorage.setItem('piq_fields',JSON.stringify(fields));localStorage.setItem('piq_samples',JSON.stringify(samples));localStorage.setItem('piq_micro',JSON.stringify(micro));render()}
function showTab(t){document.querySelectorAll('section').forEach(x=>x.hidden=x.id!==t);document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===t));if(t==='samples')fillFields();if(t==='micro')fillMicroSamples();if(t==='analysis'){renderAnalysis();fillExpertSampleSelector();}if(t==='fertilizer'){fertFillSelectors();renderFertilizerPlans();}if(t==='greenhouse'){ghRenderCropOptions();ghLoadProfile();ghRenderFertilizers();ghRenderAdminProfiles();ghRenderSeasonStatus();ghRenderSeasonLogs();}window.scrollTo({top:0,behavior:'smooth'})}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
function addField(){let name=$('fName').value.trim();if(!name){alert(lang==='fa'?'نام مزرعه را وارد کن.':'Enter a field name.');return}const lat=$('fLat').value.trim(),lon=$('fLon').value.trim();if((lat!==''||lon!=='')&&(!Number.isFinite(Number(lat))||!Number.isFinite(Number(lon))||Number(lat)<-90||Number(lat)>90||Number(lon)<-180||Number(lon)>180)){alert('مختصات معتبر وارد کن.');return}fields.push({id:Date.now(),name,loc:$('fLoc').value.trim(),area:$('fArea').value,lat:lat===''?null:Number(lat),lon:lon===''?null:Number(lon)});$('fName').value=$('fLoc').value=$('fArea').value=$('fLat').value=$('fLon').value='';save()}
function fillFields(){let s=$('sField');s.innerHTML='<option value="">'+(lang==='fa'?'انتخاب مزرعه':'Select field')+'</option>'+fields.map(f=>`<option value="${f.id}">${esc(f.name)}${f.loc?' — '+esc(f.loc):''}</option>`).join('')}
function addSample(){let fid=$('sField').value;if(!fid){alert(lang==='fa'?'ابتدا یک مزرعه ثبت و انتخاب کن.':'Create and select a field first.');return}let vals={};['ph','ec','om','n','p','k'].forEach(k=>vals[k]=$ (k).value.trim());if(!Object.values(vals).some(v=>v!=='')){alert(lang==='fa'?'حداقل یک پارامتر وارد کن.':'Enter at least one parameter.');return}
const lat=$('sLat').value.trim(),lon=$('sLon').value.trim();if((lat!==''||lon!=='')&&(!Number.isFinite(Number(lat))||!Number.isFinite(Number(lon))||Number(lat)<-90||Number(lat)>90||Number(lon)<-180||Number(lon)>180)){alert('مختصات معتبر وارد کن.');return}samples.push({id:Date.now(),fid:Number(fid),sid:$('sId').value.trim()||'S-'+(samples.length+1).toString().padStart(3,'0'),date:$('sDate').value,lat:lat===''?null:Number(lat),lon:lon===''?null:Number(lon),vals,note:$('sNote').value.trim()});['sId','sDate','sLat','sLon','ph','ec','om','n','p','k','sNote'].forEach(k=>$(k).value='');save()}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

function fillMicroSamples(){let s=$('mSample');s.innerHTML='<option value="">'+(lang==='fa'?'انتخاب نمونه خاک':'Select soil sample')+'</option>'+samples.map(x=>`<option value="${x.id}">${esc(x.sid)} — ${esc(fieldName(x.fid))}</option>`).join('')}
function addMicro(){let sid=$('mSample').value, value=$('mValue').value.trim(), unit=$('mUnit').value.trim();if(!sid){alert(lang==='fa'?'ابتدا نمونه خاک ثبت و انتخاب کن.':'Create and select a soil sample first.');return}if(value===''||unit===''){alert(lang==='fa'?'مقدار و واحد نتیجه الزامی است.':'Result value and unit are required.');return}micro.push({id:Date.now(),sid:Number(sid),type:$('mType').value,value,unit,method:$('mMethod').value.trim(),date:$('mDate').value,note:$('mNote').value.trim()});['mValue','mUnit','mMethod','mDate','mNote'].forEach(k=>$(k).value='');save()}
function microSampleName(id){return samples.find(s=>s.id===id)?.sid||'—'}
function renderMicro(){ $('microCount').textContent=micro.length;$('microList').innerHTML=micro.length?[...micro].reverse().map(m=>`<div class="sample"><div><strong>${esc(m.type)} <span class="pill">${esc(microSampleName(m.sid))}</span></strong><small class="muted">${esc(m.value)} ${esc(m.unit)} · ${esc(m.method||'روش ثبت نشده')} · ${esc(m.date||'—')}</small>${m.note?`<small class="muted">${esc(m.note)}</small>`:''}</div><button class="danger" onclick="delMicro(${m.id})">×</button></div>`).join(''):'<div class="empty">هنوز داده میکروبی ثبت نشده است.</div>';fillMicroSamples()}
function delMicro(id){if(confirm('این رکورد حذف شود؟')){micro=micro.filter(m=>m.id!==id);save()}}

function fieldName(id){return fields.find(f=>f.id===id)?.name||'—'}
function render(){ $('fieldCount').textContent=fields.length;$('sampleCount').textContent=samples.length;$('microCount').textContent=micro.length;
$('fieldList').innerHTML=fields.length?fields.map(f=>`<div class="sample"><div><strong>${esc(f.name)}</strong><small class="muted">${esc(f.loc||'—')} · ${f.area||'—'} ha</small></div><button class="danger" onclick="delField(${f.id})">×</button></div>`).join(''):'<div class="empty">هنوز مزرعه‌ای ثبت نشده است.</div>';
$('sampleList').innerHTML=samples.length?[...samples].reverse().map(s=>`<div class="sample"><div><strong>${esc(s.sid)} <span class="pill">${esc(fieldName(s.fid))}</span></strong><small class="muted">${esc(s.date||'—')} · pH ${esc(s.vals.ph||'—')} · EC ${esc(s.vals.ec||'—')}</small></div><button class="danger" onclick="delSample(${s.id})">×</button></div>`).join(''):'<div class="empty">هنوز نمونه‌ای ثبت نشده است.</div>';
$('recentList').innerHTML=samples.length?[...samples].reverse().slice(0,3).map(s=>`<div class="sample"><div><strong>${esc(s.sid)}</strong><small class="muted">${esc(fieldName(s.fid))} · ${esc(s.date||'—')}</small></div><span class="pill">pH ${esc(s.vals.ph||'—')}</span></div>`).join(''):'<div class="empty"><span>🌱</span>هنوز نمونه‌ای ثبت نشده است.</div>';fillFields();renderMicro();if(!$('analysis').hidden)renderAnalysis()}
function delField(id){if(samples.some(s=>s.fid===id)){alert('برای حذف این مزرعه ابتدا نمونه‌های وابسته را حذف کن.');return}if(confirm('این مزرعه حذف شود؟')){fields=fields.filter(f=>f.id!==id);save()}}
function delSample(id){if(confirm('این نمونه و داده‌های میکروبی وابسته به آن حذف شوند؟')){samples=samples.filter(s=>s.id!==id);micro=micro.filter(m=>m.sid!==id);save()}}
const labels={ph:'pH',ec:'EC',om:'OM %',n:'N',p:'P',k:'K'};

function fillExpertSampleSelector(){
 const s=$('expertSample'); if(!s)return;
 const prior=s.value;
 s.innerHTML=samples.map((x)=>`<option value="${x.id}">${esc(x.sid)} — ${esc(fieldName(x.fid))} — ${esc(x.date||'بدون تاریخ')}</option>`).join('');
 if(samples.some(x=>String(x.id)===prior))s.value=prior;
}
function runExpertAnalysis(){
 if(!samples.length){$('expertAnalysisResult').innerHTML='<p class="fert-note">هنوز نمونه‌ای ثبت نشده است. ابتدا نتیجه آزمایش را ثبت کن.</p>';return}
 fillExpertSampleSelector();
 const s=samples.find(x=>String(x.id)===$('expertSample').value)||samples[samples.length-1];
 const val=k=>s.vals&&s.vals[k]!==''&&s.vals[k]!=null&&Number.isFinite(Number(s.vals[k]))?Number(s.vals[k]):null;
 const out=[],missing=[];
 const ph=val('ph'),ec=val('ec'),om=val('om'),n=val('n'),p=val('p'),k=val('k');
 if(ph!==null){
  if(ph<0||ph>14)out.push(['pH','مقدار خارج از دامنه معمول اندازه‌گیری pH است؛ مقدار و ورود داده را بررسی کن.']);
  else if(ph<5.5)out.push(['pH','واکنش اسیدی: احتمال محدودیت‌هایی مانند کاهش دسترسی برخی عناصر و افزایش خطر سمیت بعضی عناصر وجود دارد. نیاز به بررسی بافت، آهک و محصول دارد.']);
  else if(ph<=7.5)out.push(['pH','در دامنه نزدیک به خنثی تا کمی قلیایی قرار دارد؛ به‌تنهایی به معنی کفایت عناصر غذایی نیست.']);
  else if(ph<=8.5)out.push(['pH','واکنش قلیایی: احتمال کاهش دسترسی آهن، روی و فسفر در برخی خاک‌ها مطرح است. آهک فعال و بی‌کربنات آب باید بررسی شود.']);
  else out.push(['pH','قلیائیت شدید: بررسی سدیمی‌بودن، کربنات/بی‌کربنات و SAR آب یا عصاره خاک ضروری است؛ pH به‌تنهایی تشخیص سدیمی‌بودن نیست.']);
 } else missing.push('pH ثبت نشده است.');
 if(ec!==null){
  if($('expertECMethod').value==='ece'){
   if(ec<0)out.push(['ECe','مقدار منفی معتبر نیست؛ واحد و داده را بررسی کن.']);
   else if(ec<2)out.push(['ECe','شوری عصاره اشباع کمتر از ۲ dS/m است؛ برای بسیاری از محصولات محدودیت شوری معمولاً کم است، اما حساسیت محصول و مرحله رشد مهم است.']);
   else if(ec<4)out.push(['ECe','۲ تا ۴ dS/m: شوری خفیف؛ احتمال افت عملکرد در محصولات حساس وجود دارد.']);
   else if(ec<8)out.push(['ECe','۴ تا ۸ dS/m: شوری متوسط؛ انتخاب محصول، کیفیت آب و مدیریت آبشویی اهمیت بالایی دارد.']);
   else if(ec<16)out.push(['ECe','۸ تا ۱۶ dS/m: شوری زیاد؛ محدودیت جدی برای بسیاری از محصولات محتمل است.']);
   else out.push(['ECe','۱۶ dS/m یا بیشتر: شوری بسیار زیاد؛ ارزیابی تخصصی آب، زهکشی، بافت و تحمل محصول ضروری است.']);
  } else missing.push('EC ثبت شده اما روش آن عصاره اشباع نیست یا نامشخص است؛ طبقه‌بندی شوری با آستانه‌های ECe انجام نشد.');
 } else missing.push('EC ثبت نشده است.');
 if(om!==null){
  if(om<0)out.push(['ماده آلی','مقدار منفی معتبر نیست؛ داده را بررسی کن.']);
  else if(om<1)out.push(['ماده آلی','کمتر از ۱٪: مقدار پایین در یک ارزیابی عمومی؛ تفسیر نهایی به اقلیم، بافت، عمق و روش اندازه‌گیری وابسته است.']);
  else if(om<2)out.push(['ماده آلی','۱ تا ۲٪: مقدار نسبتاً کم تا متوسط در ارزیابی عمومی؛ روند تغییر و بافت خاک نیز بررسی شود.']);
  else if(om<3)out.push(['ماده آلی','۲ تا ۳٪: دامنه متوسط در بسیاری از ارزیابی‌های عمومی؛ معیار منطقه‌ای و بافت تعیین‌کننده‌اند.']);
  else out.push(['ماده آلی','۳٪ یا بیشتر: مقدار نسبتاً بالا در یک ارزیابی عمومی؛ کیفیت ماده آلی و ظرفیت نگهداری آب و عناصر نیز مهم است.']);
 } else missing.push('ماده آلی ثبت نشده است.');
 if(n!==null)missing.push('N ثبت شده است ('+($('expertNUnit').value==='unknown'?'واحد نامشخص':$('expertNUnit').selectedOptions[0].text)+')، اما شکل نیتروژن (کل، نیتراتی، آمونیومی و...) و روش آزمایش و حدود بحرانی منطقه‌ای لازم است.');
 if(p!==null)missing.push('فسفر ثبت شده است؛ روش انتخابی: '+$('expertPMethod').selectedOptions[0].text+'. واحد، محصول، بافت و حدود بحرانی کالیبره‌شده منطقه‌ای نیز لازم است؛ صرف نام روش برای طبقه‌بندی کافی نیست.');
 if(k!==null)missing.push('پتاسیم ثبت شده است؛ روش انتخابی: '+$('expertKMethod').selectedOptions[0].text+'. واحد، بافت/CEC، محصول و حدود بحرانی کالیبره‌شده منطقه‌ای نیز لازم است.');
 if([n,p,k].every(x=>x===null))missing.push('مقادیر N، P و K در این نمونه وارد نشده‌اند.');
 const htmlOut=`<div class="fert-note"><b>نتیجه تحلیل نمونه ${esc(s.sid)}</b><p>مزرعه: ${esc(fieldName(s.fid))} · تاریخ: ${esc(s.date||'ثبت نشده')}</p>${out.length?'<h3>تفسیر شاخص‌های قابل تفسیر</h3><ul>'+out.map(x=>`<li><b>${x[0]}:</b> ${x[1]}</li>`).join('')+'</ul>':'<p>داده کافی برای تفسیر شاخص‌های عمومی وجود ندارد.</p>'}${missing.length?'<h3>موارد نیازمند تکمیل</h3><ul>'+missing.map(x=>`<li>${x}</li>`).join('')+'</ul>':''}<p><b>اقدام بعدی:</b> برای توصیه کودی، نتایج کامل با واحد و روش آزمایش، بافت خاک، عمق نمونه‌برداری، محصول و عملکرد هدف، کیفیت آب و سابقه کوددهی لازم است.</p></div><p class="fert-small">این خروجی غربالگری و تفسیر مقدماتی است؛ حدود عمومی فوق جایگزین کالیبراسیون منطقه‌ای و تفسیر آزمایشگاه/کارشناس نیستند. از این داده‌ها به‌تنهایی نسخه کود صادر نشده است.</p>`;
 $('expertAnalysisResult').innerHTML=htmlOut;
 window.lastExpertAnalysisHTML=htmlOut;
}
function renderAnalysis(){if(!samples.length){$('chart').className='empty';$('chart').textContent='برای نمایش نمودار، ابتدا نمونه ثبت کن.';$('latestValues').innerHTML='';return}
let last=samples[samples.length-1],arr=Object.keys(labels).map(k=>({k,v:Number(last.vals[k])})).filter(x=>last.vals[x.k]!==''&&Number.isFinite(x.v));if(!arr.length){$('chart').textContent='در آخرین نمونه مقدار عددی ثبت نشده است.';return}
let max=Math.max(...arr.map(x=>Math.abs(x.v)),1);$('chart').className='chart';$('chart').innerHTML=arr.map(x=>`<div class="barwrap"><b style="font-size:11px">${x.v}</b><div class="bar" style="height:${Math.max(4,Math.abs(x.v)/max*105)}px"></div><small>${labels[x.k]}</small></div>`).join('');$('latestValues').innerHTML=`<p class="muted">نمونه مبنا: ${esc(last.sid)} · ${esc(fieldName(last.fid))}</p><div class="metrics">${arr.map(x=>`<div class="metric"><b>${x.v}</b><small>${labels[x.k]}</small></div>`).join('')}</div>`}
function exportCSV(){if(!samples.length){alert('هنوز داده‌ای برای خروجی وجود ندارد.');return}let rows=[['Record type','Sample ID','Field','Date','Indicator','Value','Unit','Method','pH','EC (dS/m)','OM (%)','N','P','K','Notes'],...samples.map(s=>['Soil chemistry',s.sid,fieldName(s.fid),s.date,'','','', '',...['ph','ec','om','n','p','k'].map(k=>s.vals[k]),s.note]),...micro.map(m=>{let s=samples.find(x=>x.id===m.sid);return ['Soil biology',microSampleName(m.sid),s?fieldName(s.fid):'',m.date,m.type,m.value,m.unit,m.method,'','','','','','',m.note]})];let csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');download(csv,'pedoniq-soil-data.csv','text/csv;charset=utf-8')}



let fertilizerPlans=JSON.parse(localStorage.getItem('piq_fertilizer_plans')||'[]');
let lastFertilizerResult=null;
function fertFillSelectors(){
 const f=$('fertField'); if(f) f.innerHTML='<option value="">انتخاب مزرعه</option>'+fields.map(x=>`<option value="${x.id}">${esc(x.name)}${x.loc?' — '+esc(x.loc):''}</option>`).join('');
 const s=$('fertSample'); if(s) s.innerHTML='<option value="">بدون انتخاب نمونه</option>'+samples.map(x=>`<option value="${x.id}">${esc(x.sid)} — ${esc(fieldName(x.fid))}</option>`).join('');
}
function fertUseField(){
 const f=fields.find(x=>x.id===Number($('fertField').value)); if(!f)return;
 $('fertFieldName').value=f.name||''; if(f.area)$('fertArea').value=f.area;
}
function fertLoadSample(){
 const s=samples.find(x=>x.id===Number($('fertSample').value)); if(!s)return;
 $('fertPH').value=s.vals.ph||'';$('fertEC').value=s.vals.ec||'';$('fertOM').value=s.vals.om||'';
 $('fertN').value=s.vals.n||'';$('fertP').value=s.vals.p||'';$('fertK').value=s.vals.k||'';
 const f=fields.find(x=>x.id===s.fid); if(f){$('fertField').value=String(f.id);fertUseField()}
}
function fertRoleChanged(){
 const role=$('fertRole').value;
 $('fertAdminCard').hidden=role!=='admin';
 document.querySelectorAll('.expert-only').forEach(x=>x.hidden=role==='farmer');
}
function fertServiceChanged(){
 const service=$('fertService').value, plan=$('fertPlanForm'), other=$('fertOtherService');
 plan.hidden=service!=='plan'; other.hidden=service==='plan';
 const content={
  lab:['ثبت و بررسی آزمایش خاک','برای ثبت کامل نتایج شیمیایی و زیستی، از بخش آزمایش خاک استفاده کن. واحد، روش آزمون و عمق نمونه‌برداری را همراه نتایج ثبت کن. سامانه از روی داده ناقص، تشخیص قطعی صادر نمی‌کند.'],
  symptom:['بررسی اولیه علائم گیاه','علائم ظاهری به‌تنهایی برای تشخیص کمبود کافی نیستند. نوع محصول، مرحله رشد، الگوی پراکنش علائم، سابقه آبیاری و کوددهی و در صورت امکان آزمایش خاک و بافت گیاه باید بررسی شوند. این بخش فعلاً مسیر ثبت اطلاعات و ارجاع به کارشناس است و تشخیص خودکار قطعی نمی‌دهد.'],
  report:['گزارش تخصصی مزرعه','اطلاعات مزرعه و نمونه‌های ثبت‌شده را از بخش گزارش داده‌های خاک دریافت کن. برای گزارش نسخه کودی، ابتدا برنامه را در حالت تنظیم برنامه کودی تکمیل و ذخیره کن.']
 };
 const v=content[service]||content.lab; $('fertOtherTitle').textContent=v[0];$('fertOtherText').textContent=v[1];
}
function fertilizerNumber(id){const v=$(id).value.trim();return v===''?null:Number(v)}
function fertProductCalc(targetId,percentId,nameId,area){
 const target=fertilizerNumber(targetId),percent=fertilizerNumber(percentId),name=$(nameId).value.trim();
 if(target===null||target===0)return {name:name||'—',target:target||0,percent,rateHa:0,total:0,valid:true};
 if(percent===null||percent<=0||percent>100)return {name:name||'—',target,percent,rateHa:null,total:null,valid:false};
 const rate=target/(percent/100);
 return {name:name||'کود بدون نام',target,percent,rateHa:rate,total:rate*area,valid:true};
}
function calculateFertilizer(){
 const area=fertilizerNumber('fertArea');
 const crop=$('fertCrop').value;
 const targets=['fertTargetN','fertTargetP','fertTargetK'].map(fertilizerNumber);
 const splits=['fertSplitBase','fertSplitVeg','fertSplitRep'].map(fertilizerNumber);
 if(!area||area<=0||!crop){alert('مساحت معتبر و نوع محصول را وارد کن.');return}
 if(targets.every(v=>v===null||v===0)){alert('حداقل یک نرخ عنصر غذایی تأییدشده وارد کن.');return}
 if(splits.some(v=>v===null||v<0||v>100)||Math.abs(splits.reduce((a,b)=>a+b,0)-100)>0.001){alert('درصدهای زمان‌بندی باید در مجموع دقیقاً ۱۰۰ باشند.');return}
 const prods=[
  fertProductCalc('fertTargetN','fertNPercent','fertNName',area),
  fertProductCalc('fertTargetP','fertPPercent','fertPName',area),
  fertProductCalc('fertTargetK','fertKPercent','fertKName',area)
 ];
 if(prods.some(p=>!p.valid)){alert('برای هر عنصر دارای نرخ هدف، درصد معتبر کود را مطابق برچسب وارد کن.');return}
 const source=$('fertSource').value.trim(),confirmed=$('fertConfirmSource').checked&&$('fertConfirmData').checked;
 const warnings=[];
 if(!source)warnings.push('منبع نرخ توصیه ثبت نشده است.');
 if(!confirmed)warnings.push('اطلاعات یا نرخ توصیه هنوز توسط کاربر تأیید نشده است.');
 if(!$('fertMethod').value.trim())warnings.push('روش آزمایش خاک ثبت نشده است.');
 if(!$('fertTexture').value)warnings.push('بافت خاک مشخص نشده است.');
 if(!$('fertDepth').value)warnings.push('عمق نمونه‌برداری مشخص نشده است.');
 const splitNames=['پیش‌کاشت / پایه','رشد رویشی','مرحله زایشی / تکمیلی'];
 const schedule=prods.map(p=>({name:p.name,stages:splits.map((pct,i)=>({stage:splitNames[i],percent:pct,kgHa:p.rateHa===null?null:p.rateHa*pct/100,totalKg:p.total===null?null:p.total*pct/100}))}));
 lastFertilizerResult={
  id:Date.now(),date:new Date().toISOString(),role:$('fertRole').value,service:'plan',level:$('fertLevel').value,
  field:$('fertFieldName').value.trim(),area,crop,cultivar:$('fertCultivar').value.trim(),stage:$('fertStage').value,
  yieldTarget:$('fertYield').value,irrigation:$('fertIrrigation').value,texture:$('fertTexture').value,
  sample:$('fertSample').value,depth:$('fertDepth').value,soil:{ph:$('fertPH').value,ec:$('fertEC').value,om:$('fertOM').value,n:$('fertN').value,p:$('fertP').value,k:$('fertK').value,water:$('fertWater').value,method:$('fertMethod').value},
  targets:{n:targets[0]||0,p2o5:targets[1]||0,k2o:targets[2]||0},source,regionYear:$('fertRegionYear').value,approver:$('fertApprover').value,
  products:prods,splits,schedule,scheduleNote:$('fertScheduleNote').value,warnings,confirmed
 };
 renderFertilizerResult(lastFertilizerResult);
}
function fmtKg(v){return v===null?'—':Number(v).toLocaleString('fa-IR',{maximumFractionDigits:1})}
function renderFertilizerResult(p){
 const box=$('fertResult');box.hidden=false;
 const rows=p.products.filter(x=>x.target>0).map(x=>`<tr><td>${esc(x.name)}</td><td>${fmtKg(x.target)}</td><td>${fmtKg(x.percent)}٪</td><td>${fmtKg(x.rateHa)}</td><td>${fmtKg(x.total)}</td></tr>`).join('');
 const sched=p.schedule.map(x=>`<tr><td>${esc(x.name)}</td>${x.stages.map(s=>`<td>${fmtKg(s.totalKg)} kg</td>`).join('')}</tr>`).join('');
 box.innerHTML=`<h3>پیش‌نمایش محاسبات برنامه کودی</h3>
 <div class="metrics"><div class="metric"><b>${esc(p.crop)}</b><small>محصول</small></div><div class="metric"><b>${fmtKg(p.area)}</b><small>مساحت (هکتار)</small></div><div class="metric"><b>${p.confirmed?'تأیید اولیه':'پیش‌نویس'}</b><small>وضعیت داده‌ها</small></div></div>
 <div class="report-table-wrap"><table class="fert-table"><tr><th>کود</th><th>نرخ عنصر kg/ha</th><th>درصد برچسب</th><th>کود kg/ha</th><th>کل برای مزرعه (kg)</th></tr>${rows}</table></div>
 <h3 style="margin-top:16px">تقسیم مقدار کل کود در مراحل</h3><div class="report-table-wrap"><table class="fert-table"><tr><th>کود</th><th>پایه</th><th>رویشی</th><th>تکمیلی</th></tr>${sched}</table></div>
 ${p.warnings.length?`<div class="fert-note"><b>موارد نیازمند تکمیل / تأیید:</b><ul>${p.warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul></div>`:'<div class="fert-note">اطلاعات پایه و منبع نرخ توسط کاربر تأیید شده‌اند؛ با این حال، برنامه باید از نظر تناسب با محصول، اقلیم، کیفیت آب و محدودیت‌های مزرعه توسط کارشناس بررسی شود.</div>'}
 <p class="fert-small">محاسبه فقط تبدیل نرخ عنصر غذایی واردشده به مقدار کود تجاری بر اساس درصد برچسب است؛ نرخ‌های هدف به‌صورت خودکار از آزمایش خاک استنتاج نشده‌اند.</p>`;
}
function saveFertilizerPlan(){
 if(!lastFertilizerResult){calculateFertilizer();if(!lastFertilizerResult)return}
 fertilizerPlans.push(lastFertilizerResult);localStorage.setItem('piq_fertilizer_plans',JSON.stringify(fertilizerPlans));renderFertilizerPlans();alert('برنامه در همین دستگاه ذخیره شد. برای نگهداری بلندمدت از نسخه پشتیبان استفاده کن.');
}
function renderFertilizerPlans(){
 const el=$('fertPlanList');if(!el)return;
 el.innerHTML=fertilizerPlans.length?[...fertilizerPlans].reverse().map(p=>`<div class="fert-record"><div><strong>${esc(p.field||'مزرعه بدون نام')} · ${esc(p.crop)}</strong><div class="fert-small">${fmtKg(p.area)} هکتار · ${new Date(p.date).toLocaleDateString('fa-IR')} · ${p.warnings.length?'پیش‌نویس / نیازمند بررسی':'دارای تأیید اولیه'}</div></div><div><button class="secondary" onclick="openSavedFertilizer(${p.id})">مشاهده</button> <button class="danger" onclick="deleteFertilizerPlan(${p.id})">×</button></div></div>`).join(''):'<div class="empty">هنوز برنامه‌ای ذخیره نشده است.</div>';
}
function openSavedFertilizer(id){const p=fertilizerPlans.find(x=>x.id===id);if(!p)return;lastFertilizerResult=p;renderFertilizerResult(p);$('fertService').value='plan';fertServiceChanged();$('fertResult').scrollIntoView({behavior:'smooth',block:'center'})}
function deleteFertilizerPlan(id){if(confirm('این برنامه کودی حذف شود؟')){fertilizerPlans=fertilizerPlans.filter(x=>x.id!==id);localStorage.setItem('piq_fertilizer_plans',JSON.stringify(fertilizerPlans));renderFertilizerPlans()}}
function printFertilizerReport(){
 if(!lastFertilizerResult){calculateFertilizer();if(!lastFertilizerResult)return}
 const p=lastFertilizerResult,rows=p.products.filter(x=>x.target>0).map(x=>`<tr><td>${esc(x.name)}</td><td>${fmtKg(x.target)}</td><td>${fmtKg(x.percent)}٪</td><td>${fmtKg(x.rateHa)}</td><td>${fmtKg(x.total)}</td></tr>`).join('');
 const sr=p.schedule.map(x=>`<tr><td>${esc(x.name)}</td>${x.stages.map(s=>`<td>${fmtKg(s.totalKg)}</td>`).join('')}</tr>`).join('');
 const shell=document.createElement('div');shell.id='reportShell';shell.className='report-shell';
 shell.innerHTML=`<div class="report-toolbar"><button class="secondary" onclick="closeReport()">← بازگشت به برنامه</button><button class="primary" onclick="requestReportPrint()">چاپ / ذخیره PDF</button></div>
 <div class="report-page"><div class="report-head"><div class="report-brand">Pedon<span>IQ</span></div><div class="report-kicker">FERTILIZER ADVISOR</div><h1>گزارش برنامه تغذیه و توصیه کودی</h1><p>تاریخ تهیه: ${new Date(p.date).toLocaleDateString('fa-IR')}</p></div>
 <div class="report-body"><div class="report-meta"><div><small>مزرعه</small><b>${esc(p.field||'—')}</b></div><div><small>محصول</small><b>${esc(p.crop)}</b></div><div><small>مساحت</small><b>${fmtKg(p.area)} هکتار</b></div></div>
 <section class="report-section"><h2>مشخصات و داده‌های مبنا</h2><p>مرحله رشد: ${esc(p.stage||'—')} · بافت: ${esc(p.texture||'—')} · آبیاری: ${esc(p.irrigation||'—')} · عمق نمونه: ${esc(p.depth||'—')} cm</p><p>آزمایش خاک: pH ${esc(p.soil.ph||'—')} · EC ${esc(p.soil.ec||'—')} · ماده آلی ${esc(p.soil.om||'—')}٪ · روش: ${esc(p.soil.method||'—')}</p><p>منبع نرخ توصیه: ${esc(p.source||'ثبت نشده')} · منطقه/سال: ${esc(p.regionYear||'—')} · تأییدکننده: ${esc(p.approver||'—')}</p></section>
 <section class="report-section"><h2>مقدار کود محاسبه‌شده</h2><div class="report-table-wrap"><table class="report-table"><tr><th>کود</th><th>نرخ عنصر kg/ha</th><th>درصد برچسب</th><th>کود kg/ha</th><th>کل مزرعه kg</th></tr>${rows}</table></div></section>
 <section class="report-section"><h2>تقسیم زمان‌بندی (کیلوگرم برای کل مزرعه)</h2><div class="report-table-wrap"><table class="report-table"><tr><th>کود</th><th>پایه</th><th>رویشی</th><th>تکمیلی</th></tr>${sr}</table></div></section>
 ${p.warnings.length?`<div class="report-note"><b>هشدارها:</b><ul>${p.warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul></div>`:''}
 <div class="report-note"><b>روش محاسبه و محدودیت علمی:</b> مقدار کود تجاری از تقسیم نرخ عنصر غذایی واردشده بر کسر درصد تضمین‌شده روی برچسب محاسبه شده است. نرخ عناصر غذایی از آزمایش خاک به‌صورت خودکار استنتاج نشده و باید بر پایه توصیه معتبر منطقه‌ای یا نظر کارشناس تعیین شود. پیش از اجرا، سازگاری منابع، زمان مصرف، کیفیت آب، شوری، بافت و شرایط مزرعه بررسی شود. این گزارش جایگزین تأیید کارشناس نیست.</div>
 </div><div class="report-foot"><span>PedonIQ · Fertilizer Advisor</span><span>گزارش از داده‌های واردشده کاربر</span></div></div>`;
 const old=$('reportShell');if(old)old.remove();document.body.appendChild(shell);document.body.classList.add('report-open');if(window.PedonIQBridge)window.PedonIQBridge.setReportOpen(true);window.scrollTo(0,0);
}

function geoFeatures(){
 const out=[];
 fields.forEach(f=>{if(f.lat!=null&&f.lon!=null)out.push({type:"Feature",geometry:{type:"Point",coordinates:[Number(f.lon),Number(f.lat)]},properties:{kind:"field",name:f.name,location:f.loc||"",area_ha:f.area||""}})});
 samples.forEach(x=>{if(x.lat!=null&&x.lon!=null)out.push({type:"Feature",geometry:{type:"Point",coordinates:[Number(x.lon),Number(x.lat)]},properties:{kind:"soil_sample",sample_id:x.sid,field:fieldName(x.fid),date:x.date||""}})});
 return out;
}
function exportGeoJSON(){
 const features=geoFeatures();if(!features.length){alert("ابتدا برای مزرعه یا نمونه مختصات وارد کن.");return}
 download(JSON.stringify({type:"FeatureCollection",features},null,2),"pedoniq-points.geojson","application/geo+json");
}
function exportKML(){
 const features=geoFeatures();if(!features.length){alert("ابتدا برای مزرعه یا نمونه مختصات وارد کن.");return}
 const escXml=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
 const placemarks=features.map(f=>{const p=f.properties,c=f.geometry.coordinates;const name=p.name||p.sample_id||"Point";return `<Placemark><name>${escXml(name)}</name><description>${escXml(JSON.stringify(p))}</description><Point><coordinates>${c[0]},${c[1]},0</coordinates></Point></Placemark>`}).join("");
 download(`<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>PedonIQ points</name>${placemarks}</Document></kml>`,"pedoniq-points.kml","application/vnd.google-earth.kml+xml");
}

function backupData(){
 const payload={app:"PedonIQ",schemaVersion:3,createdAt:new Date().toISOString(),fields,samples,micro,fertilizerPlans,ghFertilizers,ghProfiles,ghCropNames,ghSeasonProfiles,ghSeasonLogs};
 download(JSON.stringify(payload,null,2),"pedoniq-backup-"+new Date().toISOString().slice(0,10)+".json","application/json");
}
function restoreData(event){
 const file=event.target.files&&event.target.files[0]; if(!file)return;
 const reader=new FileReader();
 reader.onload=()=>{
  try{
   const d=JSON.parse(reader.result);
   if(d.app!=="PedonIQ"||!Array.isArray(d.fields)||!Array.isArray(d.samples)||!Array.isArray(d.micro)) throw new Error("invalid");
   if(!confirm("اطلاعات فعلی با اطلاعات فایل پشتیبان جایگزین شود؟")){event.target.value="";return}
   fields=d.fields;samples=d.samples;micro=d.micro;fertilizerPlans=Array.isArray(d.fertilizerPlans)?d.fertilizerPlans:[];ghFertilizers=Array.isArray(d.ghFertilizers)?d.ghFertilizers:[];ghProfiles=d.ghProfiles&&typeof d.ghProfiles==='object'?d.ghProfiles:{};ghCropNames=d.ghCropNames&&typeof d.ghCropNames==='object'?d.ghCropNames:{tomato:'گوجه‌فرنگی',pepper:'فلفل دلمه‌ای'};localStorage.setItem('piq_gh_crops',JSON.stringify(ghCropNames));localStorage.setItem('piq_gh_fertilizers',JSON.stringify(ghFertilizers));ghSeasonProfiles=d.ghSeasonProfiles&&typeof d.ghSeasonProfiles==='object'?d.ghSeasonProfiles:{};ghSeasonLogs=d.ghSeasonLogs&&typeof d.ghSeasonLogs==='object'?d.ghSeasonLogs:{};localStorage.setItem('piq_gh_season_profiles',JSON.stringify(ghSeasonProfiles));localStorage.setItem('piq_gh_season_logs',JSON.stringify(ghSeasonLogs));localStorage.setItem('piq_gh_profiles',JSON.stringify(ghProfiles));localStorage.setItem('piq_fertilizer_plans',JSON.stringify(fertilizerPlans));save();renderFertilizerPlans();
   alert("بازیابی اطلاعات انجام شد.");
  }catch(e){alert("فایل پشتیبان معتبر PedonIQ نیست یا آسیب دیده است.")}
  event.target.value="";
 };
 reader.onerror=()=>{alert("خواندن فایل ناموفق بود.");event.target.value=""};
 reader.readAsText(file);
}


// Greenhouse module: local product library + expert-managed crop-stage profiles.
let ghFertilizers=JSON.parse(localStorage.getItem('piq_gh_fertilizers')||'[]');
let ghProfiles=JSON.parse(localStorage.getItem('piq_gh_profiles')||'{}');
let ghLastPlan=null;
let ghCropNames=JSON.parse(localStorage.getItem('piq_gh_crops')||'null')||{tomato:'گوجه‌فرنگی',pepper:'فلفل دلمه‌ای'};
const ghStageNames={establishment:'استقرار پس از نشاکاری',vegetative:'رشد رویشی',flowering:'گلدهی و تشکیل میوه',fruiting:'رشد و برداشت میوه'};
function ghRenderCropOptions(){['ghCrop','ghAdminCrop'].forEach(id=>{const el=$(id);if(!el)return;const old=el.value;el.innerHTML=Object.entries(ghCropNames).map(([k,v])=>`<option value="${esc(k)}">${esc(v)}</option>`).join('');if(ghCropNames[old])el.value=old;});}
function ghAddCrop(){const name=$('ghNewCropName').value.trim();if(!name){alert('نام محصول را وارد کن.');return}const key='crop_'+Date.now().toString(36);ghCropNames[key]=name;localStorage.setItem('piq_gh_crops',JSON.stringify(ghCropNames));$('ghNewCropName').value='';ghRenderCropOptions();$('ghCrop').value=key;$('ghAdminCrop').value=key;ghLoadProfile();alert('محصول اضافه شد. برای صدور نسخه، پروفایل علمی هر مرحله را تکمیل و تأیید کن.');}
function ghKey(c,s){return c+'_'+s}
function ghLoadProfile(){
 const c=$('ghCrop').value,s=$('ghStage').value,p=ghProfiles[ghKey(c,s)];
 $('ghProfileStatus').innerHTML=p?`پروفایل ${ghCropNames[c]} / ${ghStageNames[s]}: ${p.validated?'تأییدشده':'پیش‌نویس'} · منبع: ${esc(p.source||'ثبت نشده')} · منطقه: ${esc(p.region||'ثبت نشده')}`:'برای این محصول و مرحله هنوز پروفایل نرخ معتبر ثبت نشده است. مدیر علمی باید نرخ‌ها و منبع آن‌ها را ثبت و اعتبارسنجی کند؛ تا آن زمان نسخه خودکار صادر نمی‌شود.';
}
function ghAddFertilizer(){
 const name=$('ghFName').value.trim();if(!name){alert('نام کود را وارد کن.');return}
 const vals=['ghFN','ghFP','ghFK','ghFCa','ghFMg','ghFS'].map(id=>Number($(id).value||0));
 if(vals.some(v=>v<0||v>100)||vals.reduce((a,b)=>a+b,0)>150){alert('درصدهای آنالیز را با برچسب کنترل کن. مجموع غیرعادی است.');return}
 ghFertilizers.push({id:Date.now(),name,brand:$('ghFBrand').value.trim(),n:vals[0],p:vals[1],k:vals[2],ca:vals[3],mg:vals[4],s:vals[5],form:$('ghFForm').value,stock:$('ghStock').value===''?null:Number($('ghStock').value),note:$('ghFNote').value.trim()});
 localStorage.setItem('piq_gh_fertilizers',JSON.stringify(ghFertilizers));['ghFName','ghFBrand','ghFN','ghFP','ghFK','ghFCa','ghFMg','ghFS','ghStock','ghFNote'].forEach(id=>$(id).value='');ghRenderFertilizers();
}
function ghRenderFertilizers(){const el=$('ghFertList');if(!el)return;el.innerHTML=ghFertilizers.length?ghFertilizers.map(f=>`<div class="gh-profile"><b>${esc(f.name)}</b> ${esc(f.brand||'')} · N ${f.n}% / P₂O₅ ${f.p}% / K₂O ${f.k}% · ${f.form==='soluble'?'کاملاً محلول':f.form==='liquid'?'مایع':f.form==='granular'?'گرانوله':'حلالیت نامشخص'} · موجودی: ${f.stock===null?'ثبت نشده':fmtKg(f.stock)+' kg'}<div>${esc(f.note||'')}</div><div class="gh-actions"><button class="danger" onclick="ghDeleteFertilizer(${f.id})">حذف</button></div></div>`).join(''):'<div class="empty">هنوز کودی ثبت نشده است.</div>'}
function ghDeleteFertilizer(id){if(!confirm('این کود از بانک همین دستگاه حذف شود؟'))return;ghFertilizers=ghFertilizers.filter(f=>f.id!==id);localStorage.setItem('piq_gh_fertilizers',JSON.stringify(ghFertilizers));ghRenderFertilizers()}
function ghSaveProfile(){
 const c=$('ghAdminCrop').value,s=$('ghAdminStage').value,vals=['ghRateN','ghRateP','ghRateK'].map(id=>$(id).value.trim());
 const source=$('ghSource').value.trim(),region=$('ghRegion').value.trim(),approver=$('ghApprover').value.trim(),validated=$('ghValidated').value==='validated';
 if(vals.every(v=>v==='')){alert('حداقل یک نرخ عنصر غذایی لازم است.');return}
 if(validated&&(!source||!region||!approver||vals.some(v=>v===''))){alert('برای تأیید علمی، هر سه نرخ N/P₂O₅/K₂O، منبع دقیق، منطقه و تأییدکننده لازم است.');return}
 const rates=vals.map(v=>v===''?null:Number(v));if(rates.some(v=>v!==null&&(!Number.isFinite(v)||v<0))){alert('نرخ‌ها باید عدد مثبت یا صفر باشند.');return}
 ghProfiles[ghKey(c,s)]={crop:c,stage:s,n:rates[0],p:rates[1],k:rates[2],days:Number($('ghDays').value)||null,region,source,approver,validated,updated:new Date().toISOString()};
 localStorage.setItem('piq_gh_profiles',JSON.stringify(ghProfiles));ghRenderAdminProfiles();ghLoadProfile();alert('پروفایل ذخیره شد.');
}
function ghLoadAdminProfile(){const p=ghProfiles[ghKey($('ghAdminCrop').value,$('ghAdminStage').value)];if(!p){alert('برای این محصول و مرحله پروفایلی وجود ندارد.');return} $('ghRateN').value=p.n??'';$('ghRateP').value=p.p??'';$('ghRateK').value=p.k??'';$('ghDays').value=p.days??'';$('ghRegion').value=p.region||'';$('ghSource').value=p.source||'';$('ghApprover').value=p.approver||'';$('ghValidated').value=p.validated?'validated':'draft'}
function ghRenderAdminProfiles(){const el=$('ghAdminList');if(!el)return;const arr=Object.values(ghProfiles);el.innerHTML=arr.length?arr.map(p=>`<div class="gh-profile"><b>${ghCropNames[p.crop]} · ${ghStageNames[p.stage]}</b> — N ${p.n??'—'} / P₂O₅ ${p.p??'—'} / K₂O ${p.k??'—'} kg/ha · ${p.validated?'تأییدشده':'پیش‌نویس'}<br>${esc(p.source||'بدون منبع')} · ${esc(p.region||'')}</div>`).join(''):'هیچ پروفایل علمی ثبت نشده است.'}
function ghGeneratePlan(){
 const area=Number($('ghArea').value),crop=$('ghCrop').value,stage=$('ghStage').value,p=ghProfiles[ghKey(crop,stage)];
 if(!area||area<=0){alert('مساحت گلخانه را به مترمربع وارد کن.');return}
 if(!p||!p.validated||!p.source||!p.region||!p.approver||[p.n,p.p,p.k].some(v=>v===null||!Number.isFinite(v))){alert('برای این محصول و مرحله، نرخ علمی کامل و تأییدشده وجود ندارد. از بخش مدیریت پروفایل، مرجع و نرخ معتبر را ثبت کن.');ghLoadProfile();return}
 if(!ghFertilizers.length){alert('ابتدا کودهای موجود و درصد آنالیز برچسب را در بانک کود ثبت کن.');return}
 const nutrients=[['N','نیتروژن','n',p.n],['P₂O₅','فسفات','p',p.p],['K₂O','پتاس','k',p.k]];
 // A distinct product source is selected automatically only when a single clear product is available for that nutrient.
 const results=[];let blocked=[];
 for(const [symbol,label,key,targetHa] of nutrients){
  if(targetHa===0)continue;
  const app=$('ghApplication').value;const eligible=ghFertilizers.filter(f=>Number(f[key])>0&&(app!=='fertigation'||f.form==='soluble'||f.form==='liquid'));
  if(!eligible.length){blocked.push(`برای ${label} هیچ کود دارای درصد ${symbol} در بانک ثبت نشده است.`);continue}
  eligible.sort((a,b)=>Number(b[key])-Number(a[key]));const f=eligible[0];
  const kgHa=targetHa/(Number(f[key])/100),totalKg=kgHa*(area/10000);
  results.push({nutrient:symbol,label,targetHa,fertilizer:f.name,percent:f[key],kgHa,totalKg,stock:f.stock,stockShort:f.stock!==null&&f.stock<totalKg});
  if(eligible.length>1)blocked.push(`برای ${label} چند منبع موجود بود؛ سامانه فعلاً کود با بالاترین درصد ${symbol} را برای محاسبه مقدماتی انتخاب کرد. انتخاب نهایی منبع باید با بررسی فرم شیمیایی، شوری، قیمت و سازگاری انجام شود.`);
 }
 if(blocked.length||results.length!==nutrients.filter(x=>x[3]>0).length){$('ghResult').hidden=false;$('ghResult').innerHTML='<h3>نسخه قابل صدور نیست</h3><div class="gh-warning"><ul>'+blocked.map(x=>`<li>${esc(x)}</li>`).join('')+'</ul>سامانه عمداً نسخه ناقص را به‌عنوان توصیه نهایی نشان نمی‌دهد.</div>';ghLastPlan=null;return}
 const warnings=[];if(!$('ghWaterEC').value)warnings.push('EC آب آبیاری وارد نشده؛ ارزیابی خطر شوری و سهم عناصر آب ممکن نیست.');if(!$('ghSoilEC').value||!$('ghExtract').value)warnings.push('EC خاک و روش/نسبت عصاره ثبت نشده؛ تفسیر شوری خاک ممکن نیست.');if(!$('ghPH').value)warnings.push('pH خاک ثبت نشده؛ ارزیابی محدودیت جذب عناصر کامل نیست.');
 results.forEach(r=>{if(r.stockShort)warnings.push(`موجودی ${r.fertilizer} (${r.stock} کیلوگرم) از مقدار محاسبه‌شده (${fmtKg(r.totalKg)} کیلوگرم) کمتر است.`)});
 const same=results.map(r=>r.fertilizer);if(new Set(same).size!==same.length)warnings.push('یک کود برای بیش از یک عنصر انتخاب شده است؛ محاسبات مستقل ممکن است هم‌پوشانی عناصر ایجاد کند و باید تراز کامل آنالیز انجام شود.');
 ghLastPlan={date:new Date().toISOString(),name:$('ghName').value.trim(),area,crop,stage,cultivar:$('ghCultivar').value.trim(),application:$('ghApplication').value,waterEC:$('ghWaterEC').value,soilEC:$('ghSoilEC').value,ph:$('ghPH').value,extract:$('ghExtract').value,profile:p,results,warnings};
 const rows=results.map(r=>`<tr><td>${r.nutrient}</td><td>${esc(r.fertilizer)} (${r.percent}٪)</td><td>${fmtKg(r.targetHa)}</td><td>${fmtKg(r.kgHa)}</td><td>${fmtKg(r.totalKg)}</td></tr>`).join('');
 $('ghResult').hidden=false;$('ghResult').innerHTML=`<h3>برنامه محاسباتی گلخانه · ${ghCropNames[crop]}</h3><div class="metrics"><div class="metric"><b>${fmtKg(area)}</b><small>مساحت m²</small></div><div class="metric"><b>${ghStageNames[stage]}</b><small>مرحله رشد</small></div><div class="metric"><b>${p.days||'—'}</b><small>روزهای بازه توصیه</small></div></div><div class="report-table-wrap"><table class="fert-table"><tr><th>عنصر</th><th>کود انتخاب‌شده</th><th>هدف kg/ha</th><th>کود kg/ha</th><th>کل گلخانه kg</th></tr>${rows}</table></div><div class="gh-warning"><b>منبع نرخ:</b> ${esc(p.source)} · ${esc(p.region)} · تأییدکننده: ${esc(p.approver)}<br>این محاسبه تبدیل نرخ عناصر ثبت‌شده در پروفایل به جرم کود تجاری است؛ نیاز غذایی از آزمایش خاک/آب کسر نشده و تقسیم روزانه/تزریق نیز تا تعیین برنامه نوبت‌دهی صادر نمی‌شود.</div>${warnings.length?'<div class="gh-warning"><b>هشدارهای لازم:</b><ul>'+warnings.map(w=>`<li>${esc(w)}</li>`).join('')+'</ul></div>':'<div class="gh-good">اطلاعات پایه آب و خاک ثبت شده است؛ کنترل نهایی سازگاری، غلظت تزریق و روش مصرف همچنان ضروری است.</div>'}<p class="fert-small">نسخه محاسباتی مبتنی بر پروفایل مدیر علمی است. پیش از اجرا باید مقدار عناصر تأمین‌شده از آب، خاک و کودهای مرکب، روش تزریق، دفعات آبیاری و سازگاری مخلوط‌ها بررسی شود.</p>`;
}
function ghPrintReport(){if(!ghLastPlan){alert('ابتدا یک برنامه محاسباتی معتبر تولید کن.');return}const p=ghLastPlan,rows=p.results.map(r=>`<tr><td>${r.nutrient}</td><td>${esc(r.fertilizer)}</td><td>${r.percent}%</td><td>${fmtKg(r.targetHa)}</td><td>${fmtKg(r.kgHa)}</td><td>${fmtKg(r.totalKg)}</td></tr>`).join('');const notes=p.warnings.map(w=>`<li>${esc(w)}</li>`).join('');const report=`<div class="report-page"><div class="report-head"><div class="report-brand">Pedon<span>IQ</span></div><div class="report-kicker">GREENHOUSE SOIL-GROWN CROP ADVISOR</div><h1>گزارش محاسبات برنامه تغذیه گلخانه</h1><p>${new Date(p.date).toLocaleDateString('fa-IR')}</p></div><div class="report-body"><div class="report-meta"><div><small>گلخانه</small><b>${esc(p.name||'—')}</b></div><div><small>محصول</small><b>${ghCropNames[p.crop]}</b></div><div><small>مساحت</small><b>${fmtKg(p.area)} مترمربع</b></div></div><section class="report-section"><h2>اطلاعات مبنا</h2><p>روش کشت: مستقیم در خاک گلخانه · روش مصرف: ${p.application==='fertigation'?'کودآبیاری قطره‌ای':'مصرف خاکی'} · رقم: ${esc(p.cultivar||'—')} · مرحله: ${ghStageNames[p.stage]}</p><p>pH خاک: ${esc(p.ph||'ثبت نشده')} · EC خاک: ${esc(p.soilEC||'ثبت نشده')} · EC آب: ${esc(p.waterEC||'ثبت نشده')} · روش عصاره: ${esc(p.extract||'ثبت نشده')}</p></section><section class="report-section"><h2>محاسبه مقدار کود</h2><div class="report-table-wrap"><table class="report-table"><tr><th>عنصر</th><th>کود</th><th>درصد برچسب</th><th>هدف kg/ha</th><th>کود kg/ha</th><th>کل kg</th></tr>${rows}</table></div></section><section class="report-section"><h2>مرجع پروفایل علمی</h2><p>${esc(p.profile.source)} · ${esc(p.profile.region)} · تأییدکننده: ${esc(p.profile.approver)}</p></section><div class="report-note"><b>هشدارها و محدودیت‌ها:</b><ul>${notes||'<li>هنوز هشدار ثبت‌شده‌ای وجود ندارد.</li>'}</ul>این گزارش جایگزین بررسی کامل تراز عناصر، کیفیت آب، سازگاری کودها و برنامه تزریق نیست.</div></div><div class="report-foot"><span>PedonIQ</span><span>نسخه محاسباتی گلخانه خاکی</span></div></div>`;const shell=document.createElement('div');shell.id='reportShell';shell.className='report-shell';shell.innerHTML=`<div class="report-toolbar"><button class="secondary" onclick="closeReport()">بازگشت</button><button class="primary" onclick="requestReportPrint()">چاپ / ذخیره PDF</button></div>${report}`;const old=$('reportShell');if(old)old.remove();document.body.appendChild(shell);document.body.classList.add('report-open');if(window.PedonIQBridge)window.PedonIQBridge.setReportOpen(true);window.scrollTo(0,0)}

function download(content,name,type){let a=document.createElement('a'),u=URL.createObjectURL(new Blob([content],{type}));a.href=u;a.download=name;a.click();URL.revokeObjectURL(u)}

function closeReport(){
 const shell=$('reportShell'); if(shell) shell.remove();
 document.body.classList.remove('report-open');
 if(window.PedonIQBridge) window.PedonIQBridge.setReportOpen(false);
 return true;
}
function printReport(){
 if(!samples.length){alert('هنوز داده‌ای برای گزارش وجود ندارد.');return}
 const rows=samples.map(s=>`<tr><td>${esc(s.sid)}</td><td>${esc(fieldName(s.fid))}</td><td>${esc(s.date)}</td>${['ph','ec','om','n','p','k'].map(k=>`<td>${esc(s.vals[k]??'—')}</td>`).join('')}</tr>`).join('');
 const mrows=micro.map(m=>`<tr><td>${esc(microSampleName(m.sid))}</td><td>${esc(m.type)}</td><td>${esc(m.value)}</td><td>${esc(m.unit)}</td><td>${esc(m.method)}</td><td>${esc(m.date)}</td></tr>`).join('');
 const report=`<div class="report-page" id="reportPage">
 <div class="report-head"><div class="report-brand">Pedon<span>IQ</span></div><div class="report-kicker">SOIL INTELLIGENCE PLATFORM</div><h1>گزارش تخصصی داده‌های خاک</h1><p>گزارش ثبت‌شده از داده‌های واردشده در سامانه · ${new Date().toLocaleDateString('fa-IR')}</p></div>
 <div class="report-body"><div class="report-meta">
 <div><small>تعداد نمونه‌های شیمیایی</small><b>${samples.length}</b></div><div><small>تعداد آزمون‌های زیستی</small><b>${micro.length}</b></div><div><small>تاریخ تهیه گزارش</small><b>${new Date().toLocaleDateString('fa-IR')}</b></div></div>
 <section class="report-section"><h2>نتایج شیمیایی خاک</h2><div class="report-table-wrap"><table class="report-table"><tr><th>شناسه نمونه</th><th>مزرعه</th><th>تاریخ</th><th>pH</th><th>EC</th><th>OM %</th><th>N</th><th>P</th><th>K</th></tr>${rows}</table></div></section>
 <section class="report-section"><h2>نتایج میکروبیولوژی خاک</h2>${mrows?`<div class="report-table-wrap"><table class="report-table"><tr><th>نمونه</th><th>شاخص زیستی</th><th>مقدار</th><th>واحد</th><th>روش</th><th>تاریخ</th></tr>${mrows}</table></div>`:'<div class="report-empty">برای این گزارش، نتیجه میکروبیولوژی ثبت نشده است.</div>'}</section>
 <section class="report-section"><h2>تفسیر مقدماتی نمونه منتخب</h2>${window.lastExpertAnalysisHTML||'<div class="report-empty">تحلیل مقدماتی در این نشست اجرا نشده است.</div>'}</section>\n <div class="report-note"><b>یادداشت علمی:</b> مقادیر همان‌طور که وارد شده‌اند نمایش داده شده‌اند. تفسیر معتبر به روش آزمایش، واحدها، ویژگی‌های خاک، عمق نمونه‌برداری و محصول هدف وابسته است. تفسیر مقدماتی فقط برای شاخص‌های دارای روش و واحد مشخص ارائه شده و به‌تنهایی نسخه کودی یا تشخیص قطعی نیست.</div>
 </div><div class="report-foot"><span>PedonIQ · Soil Intelligence Platform</span><span>گزارش تولیدشده از داده‌های ثبت‌شده</span></div></div>`;
 const old=$('reportShell');if(old)old.remove();
 const shell=document.createElement('div');shell.id='reportShell';shell.className='report-shell';
 shell.innerHTML=`<div class="report-toolbar"><button class="secondary" onclick="closeReport()">← بازگشت به برنامه</button><button class="primary" onclick="requestReportPrint()">چاپ / ذخیره PDF</button></div>${report}`;
 document.body.appendChild(shell);document.body.classList.add('report-open');
 if(window.PedonIQBridge)window.PedonIQBridge.setReportOpen(true);
 window.scrollTo(0,0);
}
function requestReportPrint(){if(window.PedonIQBridge)window.PedonIQBridge.printReport();else window.print();}
$('langBtn').onclick=()=>{lang=lang==='fa'?'en':'fa';document.documentElement.lang=lang;document.documentElement.dir=lang==='fa'?'rtl':'ltr';$('langBtn').textContent=lang==='fa'?'EN':'FA';document.querySelectorAll('[data-fa]').forEach(el=>el.textContent=el.dataset[lang]);document.querySelectorAll('input[placeholder]').forEach(el=>{if(el.id==='fName')el.placeholder=lang==='fa'?'مثلاً مزرعه شمالی':'e.g. North field';if(el.id==='fLoc')el.placeholder=lang==='fa'?'نام روستا یا منطقه':'Village or region';});render()};
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));

// PedonIQ 1.6 — persistent soil-grown greenhouse season records and transparent calculations.
let ghSeasonProfiles=JSON.parse(localStorage.getItem('piq_gh_season_profiles')||'{}');
let ghSeasonLogs=JSON.parse(localStorage.getItem('piq_gh_season_logs')||'{}');
let ghActiveSeasonId=null;
function ghSeasonId(){return ($('ghProfileId')?.value||'').trim()||'GH-01'}
function ghSaveSeasonProfile(){
 const id=ghSeasonId(), area=Number($('ghArea').value), name=$('ghName').value.trim(), plants=$('ghPlants').value.trim();
 if(!name||!area||area<=0){alert('نام و مساحت گلخانه را وارد کن.');return}
 const numeric=['ghPlants','ghEmitters','ghEmitterFlow','ghRowSpace','ghPlantSpace'].map(k=>$(k).value.trim());
 for(const k of ['ghPlants','ghEmitters','ghEmitterFlow']) if($(k).value!==''&&Number($(k).value)<=0){alert('تعداد بوته، تعداد قطره‌چکان و دبی باید مثبت باشند.');return}
 const profile={id,name,area,crop:$('ghCrop').value,cultivar:$('ghCultivar').value.trim(),stage:$('ghStage').value,plantDate:$('ghPlantDate').value,texture:$('ghTexture').value,plants:plants===''?null:Number(plants),rowSpace:$('ghRowSpace').value===''?null:Number($('ghRowSpace').value),plantSpace:$('ghPlantSpace').value===''?null:Number($('ghPlantSpace').value),emitters:$('ghEmitters').value===''?null:Number($('ghEmitters').value),emitterFlow:$('ghEmitterFlow').value===''?null:Number($('ghEmitterFlow').value),irrigationMethod:$('ghIrrigationMethod').value,previousInputs:$('ghPreviousInputs').value.trim(),note:$('ghProfileNote').value.trim(),waterEC:$('ghWaterEC').value,soilEC:$('ghSoilEC').value,ph:$('ghPH').value,extract:$('ghExtract').value,updated:new Date().toISOString()};
 ghSeasonProfiles[id]=profile;ghActiveSeasonId=id;localStorage.setItem('piq_gh_season_profiles',JSON.stringify(ghSeasonProfiles));ghRenderSeasonStatus();ghRenderSeasonLogs();alert('پرونده گلخانه ذخیره شد. سوابق این پرونده روی همین گوشی باقی می‌ماند.');
}
function ghLoadSeasonProfile(){
 const id=ghSeasonId(),p=ghSeasonProfiles[id];if(!p){alert('پرونده‌ای با این شناسه پیدا نشد.');return}
 ghActiveSeasonId=id;
 const map={ghName:p.name,ghArea:p.area,ghCrop:p.crop,ghCultivar:p.cultivar,ghStage:p.stage,ghPlantDate:p.plantDate,ghTexture:p.texture,ghPlants:p.plants,ghRowSpace:p.rowSpace,ghPlantSpace:p.plantSpace,ghEmitters:p.emitters,ghEmitterFlow:p.emitterFlow,ghIrrigationMethod:p.irrigationMethod,ghPreviousInputs:p.previousInputs,ghProfileNote:p.note,ghWaterEC:p.waterEC,ghSoilEC:p.soilEC,ghPH:p.ph,ghExtract:p.extract};
 Object.entries(map).forEach(([k,v])=>{if($(k)&&v!==null&&v!==undefined)$(k).value=v});
 ghRenderSeasonStatus();ghRenderSeasonLogs();ghLoadProfile();
}
function ghRenderSeasonStatus(){
 const el=$('ghSeasonStatus');if(!el)return;const p=ghSeasonProfiles[ghSeasonId()];
 el.innerHTML=p?`<b>پرونده فعال: ${esc(p.name)}</b> · ${esc(ghCropNames[p.crop]||p.crop)} · ${fmtKg(p.area)} مترمربع<br>بافت خاک: ${esc(p.texture||'ثبت نشده')} · تعداد بوته: ${p.plants??'ثبت نشده'} · تاریخ نشاکاری: ${esc(p.plantDate||'ثبت نشده')}<br><small>آخرین ذخیره: ${new Date(p.updated).toLocaleString('fa-IR')}</small>`:'برای این شناسه هنوز پرونده‌ای ذخیره نشده است.';
}
function ghAddSeasonLog(){
 const id=ghSeasonId();if(!ghSeasonProfiles[id]){alert('ابتدا پرونده گلخانه را ذخیره کن.');return}
 const log={id:Date.now(),date:$('ghLogDate').value||new Date().toISOString().slice(0,10),stage:$('ghLogStage').value,symptoms:$('ghSymptoms').value.trim(),actions:$('ghActionsNote').value.trim()};
 if(!log.symptoms&&!log.actions){alert('وضعیت گیاه یا اقدام انجام‌شده را وارد کن.');return}
 ghSeasonLogs[id]=ghSeasonLogs[id]||[];ghSeasonLogs[id].push(log);localStorage.setItem('piq_gh_season_logs',JSON.stringify(ghSeasonLogs));
 $('ghStage').value=log.stage==='postharvest'?'fruiting':log.stage; if(log.stage!=='postharvest')$('ghLogStage').value=log.stage;
 ghSeasonProfiles[id].stage=$('ghStage').value;ghSeasonProfiles[id].updated=new Date().toISOString();localStorage.setItem('piq_gh_season_profiles',JSON.stringify(ghSeasonProfiles));
 $('ghSymptoms').value='';$('ghActionsNote').value='';ghRenderSeasonLogs();ghRenderSeasonStatus();ghLoadProfile();
}
function ghRenderSeasonLogs(){
 const el=$('ghSeasonLogs');if(!el)return;const rows=(ghSeasonLogs[ghSeasonId()]||[]).slice().reverse();
 el.innerHTML=rows.length?rows.map(x=>`<div class="gh-profile"><b>${esc(x.date)} · ${esc(ghStageNames[x.stage]||'پایان برداشت')}</b><br>${esc(x.symptoms||'بدون علائم ثبت‌شده')}<br><small>${esc(x.actions||'اقدامی ثبت نشده')}</small></div>`).join(''):'<div class="empty">هنوز بازدیدی ثبت نشده است.</div>';
}
function ghCalculateIrrigation(){
 const area=Number($('ghArea').value),emitters=Number($('ghEmitters').value),flow=Number($('ghEmitterFlow').value),depth=$('ghIrrDepth').value===''?null:Number($('ghIrrDepth').value),eff=$('ghIrrEfficiency').value===''?100:Number($('ghIrrEfficiency').value),minutes=$('ghCurrentMinutes').value===''?null:Number($('ghCurrentMinutes').value),plants=$('ghPlants').value===''?null:Number($('ghPlants').value);
 const el=$('ghIrrResult');el.hidden=false;
 if(!(area>0&&emitters>0&&flow>0)){el.innerHTML='<h3>اطلاعات کافی نیست</h3>برای محاسبه دبی کل، مساحت گلخانه، تعداد قطره‌چکان فعال و دبی اندازه‌گیری‌شده هر قطره‌چکان را وارد کن.';return}
 if(!(eff>0&&eff<=100)){el.innerHTML='<h3>بازده نامعتبر</h3>بازده کاربرد آب باید بین ۱ تا ۱۰۰ درصد باشد.';return}
 const totalFlow=emitters*flow, delivered=minutes===null?null:totalFlow*minutes/60, lPerPlant=delivered!==null&&plants>0?delivered/plants:null;
 let target=null,run=null,perPlantTarget=null;
 if(depth!==null&&depth>=0){const grossMm=depth/(eff/100);target=area*grossMm;run=target/totalFlow*60;perPlantTarget=plants>0?target/plants:null}
 el.innerHTML=`<h3>نتیجه محاسبات سامانه</h3><div class="metrics"><div class="metric"><b>${fmtKg(totalFlow)}</b><small>دبی کل (لیتر/ساعت)</small></div><div class="metric"><b>${delivered===null?'—':fmtKg(delivered)}</b><small>حجم در زمان فعلی (لیتر)</small></div><div class="metric"><b>${lPerPlant===null?'—':fmtKg(lPerPlant)}</b><small>لیتر/بوته در زمان فعلی</small></div></div>${target===null?'<div class="gh-warning">برای محاسبه مدت لازم آبیاری، عمق آبیاری معتبر (میلی‌متر در نوبت) را وارد کن. این سامانه نیاز آبی را خودش حدس نمی‌زند.</div>':`<div class="gh-good">حجم ناخالص متناظر با عمق واردشده: <b>${fmtKg(target)} لیتر</b> (${fmtKg(target/1000)} مترمکعب)<br>زمان محاسباتی کارکرد: <b>${fmtKg(run)} دقیقه</b>${perPlantTarget===null?'':`<br>حجم معادل هر بوته: ${fmtKg(perPlantTarget)} لیتر`}</div>`}<p class="fert-small">مبنای محاسبه: تعداد قطره‌چکان × دبی اندازه‌گیری‌شده. عمق آب واردشده، بازده کاربرد و یکنواختی توزیع باید با شرایط واقعی مزرعه کنترل شوند. این خروجی به‌تنهایی زمان‌بندی روزانه یا نیاز تبخیرـتعرق را تعیین نمی‌کند.</p>`;
}
function ghGeneratePlan(){
 const area=Number($('ghArea').value),crop=$('ghCrop').value,stage=$('ghStage').value,p=ghProfiles[ghKey(crop,stage)];
 if(!(area>0)){alert('مساحت گلخانه را به مترمربع وارد کن.');return}
 const missing=[];
 if(!$('ghName').value.trim())missing.push('نام گلخانه');
 if(!$('ghTexture').value)missing.push('بافت خاک');
 if(!$('ghPH').value)missing.push('pH خاک');
 if(!$('ghSoilEC').value||!$('ghExtract').value)missing.push('EC خاک همراه روش عصاره');
 if(!$('ghWaterEC').value)missing.push('EC آب آبیاری');
 if(!$('ghPlants').value)missing.push('تعداد بوته');
 if(!$('ghPlantDate').value)missing.push('تاریخ نشاکاری');
 if(!p||!p.validated||!p.source||!p.region||!p.approver||[p.n,p.p,p.k].some(v=>v===null||!Number.isFinite(v)))missing.push('پروفایل نرخ تغذیه‌ای مستند و تأییدشده برای همین محصول و مرحله');
 const completeness=Math.max(0,100-Math.round(missing.length/8*100));
 ghLastPlan=null;$('ghResult').hidden=false;
 if(!p||!p.validated){
  $('ghResult').innerHTML=`<h3>ارزیابی مقدماتی گلخانه · ${esc(ghCropNames[crop])}</h3><div class="metrics"><div class="metric"><b>${completeness}٪</b><small>تکمیل اطلاعات مبنا</small></div><div class="metric"><b>${esc(ghStageNames[stage])}</b><small>مرحله انتخاب‌شده</small></div><div class="metric"><b>${fmtKg(area)}</b><small>مساحت (مترمربع)</small></div></div><div class="gh-warning"><b>نسخه کودی عددی صادر نشد.</b><br>برای این محصول و مرحله، نرخ محلیِ مستند و تأییدشده در بانک علمی ثبت نشده است. برنامه عمداً نرخ کود را حدس نمی‌زند.</div><b>اطلاعاتی که هنوز باید تکمیل شود:</b><ul>${missing.map(x=>`<li>${esc(x)}</li>`).join('')||'<li>اطلاعات پایه کافی است، اما مرجع نرخ مرحله‌ای هنوز ثبت نشده است.</li>'}</ul><p class="fert-small">گام بعدی: آزمایش خاک و آب با روش و واحد مشخص، بررسی سابقه کوددهی و ارزیابی مرحله رشد. پس از ثبت مرجع معتبر می‌توان نیاز غذایی و تبدیل به کود تجاری را بررسی کرد.</p>`;
  return;
 }
 const nutrientRows=[['N','نیتروژن',p.n],['P₂O₅','فسفر',p.p],['K₂O','پتاسیم',p.k]];
 const total=nutrientRows.map(([sym,label,rate])=>({sym,label,rate,kg:rate*area/10000}));
 const warnings=[];if(!$('ghTexture').value)warnings.push('بافت خاک مشخص نیست؛ ارزیابی نگهداشت آب و عناصر محدود است.');if(!$('ghWaterEC').value)warnings.push('EC آب ثبت نشده؛ سهم عناصر آب و خطر شوری ارزیابی نشده است.');if(!$('ghSoilEC').value||!$('ghExtract').value)warnings.push('EC خاک بدون روش عصاره قابل تفسیر کامل نیست.');
 ghLastPlan={date:new Date().toISOString(),name:$('ghName').value.trim(),area,crop,stage,cultivar:$('ghCultivar').value.trim(),application:$('ghApplication').value,waterEC:$('ghWaterEC').value,soilEC:$('ghSoilEC').value,ph:$('ghPH').value,extract:$('ghExtract').value,profile:p,results:[],warnings};
 $('ghResult').innerHTML=`<h3>هدف عناصر غذایی ثبت‌شده در مرجع · ${esc(ghCropNames[crop])}</h3><div class="gh-warning">این اعداد نرخ ورودی پروفایل علمی هستند، نه محاسبه نیاز خالص از آزمایش خاک و آب. قبل از اجرا باید اعتبار منطقه‌ای، بازه زمانی، منبع عناصر خاک/آب و برنامه کوددهی کامل بررسی شود.</div><div class="report-table-wrap"><table class="fert-table"><tr><th>عنصر</th><th>نرخ مرجع (kg/ha)</th><th>معادل برای این گلخانه (kg)</th></tr>${total.map(x=>`<tr><td>${x.sym} · ${x.label}</td><td>${fmtKg(x.rate)}</td><td>${fmtKg(x.kg)}</td></tr>`).join('')}</table></div><p class="fert-small">منبع: ${esc(p.source)} · منطقه/شرایط: ${esc(p.region)} · بازه: ${p.days||'نامشخص'} روز · تأییدکننده: ${esc(p.approver)}</p>${warnings.length?`<div class="gh-warning">${warnings.map(esc).join('<br>')}</div>`:''}<p class="fert-small">بانک کود تجاری اختیاری است و برای مشاهده هدف عناصر لازم نیست. برای تبدیل این اهداف به مقدار کود، باید آنالیز کامل هر محصول و سهم تمام عناصر همراه و سازگاری مصرف بررسی شود.</p>`;
}

render();fertFillSelectors();renderFertilizerPlans();fertRoleChanged();fertServiceChanged();ghRenderCropOptions();ghLoadProfile();ghRenderFertilizers();ghRenderAdminProfiles();ghRenderSeasonStatus();ghRenderSeasonLogs();
